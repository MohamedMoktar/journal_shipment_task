/*
Copyright (c) 2003-2021, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'embedbase', 'hu', {
	pathName: 'média objektum',
	title: 'Média beágyazása',
	button: 'Beágyazott média beszúrása',
	unsupportedUrlGiven: 'A megadott URL nem támogatott.',
	unsupportedUrl: 'Az URL-t {url} a média beágyazása nem támogatja.',
	fetchingFailedGiven: 'Nem sikerült a megadott URL-hez tartalmat kinyerni.',
	fetchingFailed: 'Nem sikerült az {url}-nek a tartalmát kinyerni.',
	fetchingOne: 'oEmbed válasz kinyerése...',
	fetchingMany: 'oEmbed válasz kinyerése folyamatban, {current} a {max}-ból kész...'
} );
